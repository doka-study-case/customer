--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE doka;
--
-- Name: doka; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE doka WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE doka OWNER TO postgres;

\connect doka

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: customer_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.customer_type AS ENUM (
    'INDIVIDUAL',
    'BUSINESS'
);


ALTER TYPE public.customer_type OWNER TO postgres;

--
-- Name: TYPE customer_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TYPE public.customer_type IS 'müşteri türleri
bireysel - individual
ticari - business';


--
-- Name: transaction_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.transaction_type AS ENUM (
    'DEPOSIT',
    'WITHDRAW',
    'BILL_PAYMENT',
    'SALARY_PAYMENT',
    'EFT'
);


ALTER TYPE public.transaction_type OWNER TO postgres;

--
-- Name: transfer_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.transfer_type AS ENUM (
    'INCOMING_EFT',
    'OUTGOING_EFT',
    'BILL_PAYMENT',
    'TRANSACTION_FEE',
    'OUTGOING_SALARY_PAYMENT',
    'INCOMING_SALARY_PAYMENT'
);


ALTER TYPE public.transfer_type OWNER TO postgres;

--
-- Name: customertype_to_text(public.customer_type, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.customertype_to_text(public.customer_type, text) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
    BEGIN
        RETURN $1 = $2::customer_type;
    END;
$_$;


ALTER FUNCTION public.customertype_to_text(public.customer_type, text) OWNER TO postgres;

--
-- Name: transfertype_to_text(public.transfer_type, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.transfertype_to_text(public.transfer_type, text) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
    BEGIN
        RETURN $1 = $2::transfer_type;
    END;
$_$;


ALTER FUNCTION public.transfertype_to_text(public.transfer_type, text) OWNER TO postgres;

--
-- Name: =; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR public.= (
    FUNCTION = public.customertype_to_text,
    LEFTARG = public.customer_type,
    RIGHTARG = text,
    COMMUTATOR = OPERATOR(public.=)
);


ALTER OPERATOR public.= (public.customer_type, text) OWNER TO postgres;

--
-- Name: =; Type: OPERATOR; Schema: public; Owner: postgres
--

CREATE OPERATOR public.= (
    FUNCTION = public.transfertype_to_text,
    LEFTARG = public.transfer_type,
    RIGHTARG = text,
    COMMUTATOR = OPERATOR(public.=)
);


ALTER OPERATOR public.= (public.transfer_type, text) OWNER TO postgres;

--
-- Name: CAST (character varying AS public.customer_type); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.customer_type) WITH INOUT AS ASSIGNMENT;


--
-- Name: CAST (character varying AS public.transfer_type); Type: CAST; Schema: -; Owner: -
--

CREATE CAST (character varying AS public.transfer_type) WITH INOUT AS ASSIGNMENT;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    iban text NOT NULL,
    balance numeric DEFAULT 0 NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.account OWNER TO postgres;

--
-- Name: account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_id_seq OWNER TO postgres;

--
-- Name: account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_id_seq OWNED BY public.account.id;


--
-- Name: customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE public.customer_id_seq OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id integer DEFAULT nextval('public.customer_id_seq'::regclass) NOT NULL,
    type public.customer_type NOT NULL,
    name text NOT NULL,
    address text NOT NULL,
    password text NOT NULL,
    register_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.log (
    id integer NOT NULL,
    log jsonb,
    log_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.log OWNER TO postgres;

--
-- Name: log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.log_id_seq OWNER TO postgres;

--
-- Name: log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.log_id_seq OWNED BY public.log.id;


--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    message text NOT NULL,
    notification_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_id_seq OWNER TO postgres;

--
-- Name: notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_id_seq OWNED BY public.notification.id;


--
-- Name: transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transaction (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    amount numeric DEFAULT 0 NOT NULL,
    source_account_id integer NOT NULL,
    target_account_id integer,
    corporation text,
    transaction_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    transfer_type public.transfer_type NOT NULL
);


ALTER TABLE public.transaction OWNER TO postgres;

--
-- Name: transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaction_id_seq OWNER TO postgres;

--
-- Name: transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transaction_id_seq OWNED BY public.transaction.id;


--
-- Name: account id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account ALTER COLUMN id SET DEFAULT nextval('public.account_id_seq'::regclass);


--
-- Name: log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.log ALTER COLUMN id SET DEFAULT nextval('public.log_id_seq'::regclass);


--
-- Name: notification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification ALTER COLUMN id SET DEFAULT nextval('public.notification_id_seq'::regclass);


--
-- Name: transaction id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction ALTER COLUMN id SET DEFAULT nextval('public.transaction_id_seq'::regclass);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account (id, customer_id, iban, balance, create_date) FROM stdin;
\.
COPY public.account (id, customer_id, iban, balance, create_date) FROM '$$PATH$$/3639.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id, type, name, address, password, register_date) FROM stdin;
\.
COPY public.customer (id, type, name, address, password, register_date) FROM '$$PATH$$/3637.dat';

--
-- Data for Name: log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.log (id, log, log_date) FROM stdin;
\.
COPY public.log (id, log, log_date) FROM '$$PATH$$/3641.dat';

--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification (id, customer_id, message, notification_date) FROM stdin;
\.
COPY public.notification (id, customer_id, message, notification_date) FROM '$$PATH$$/3645.dat';

--
-- Data for Name: transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transaction (id, customer_id, amount, source_account_id, target_account_id, corporation, transaction_date, transfer_type) FROM stdin;
\.
COPY public.transaction (id, customer_id, amount, source_account_id, target_account_id, corporation, transaction_date, transfer_type) FROM '$$PATH$$/3643.dat';

--
-- Name: account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_id_seq', 4, true);


--
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_id_seq', 31, true);


--
-- Name: log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.log_id_seq', 25, true);


--
-- Name: notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_id_seq', 2, true);


--
-- Name: transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaction_id_seq', 18752, true);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: log log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.log
    ADD CONSTRAINT log_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: transaction transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_pkey PRIMARY KEY (id);


--
-- Name: account unq_iban; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT unq_iban UNIQUE (iban);


--
-- Name: account fkey_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT fkey_customer_id FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- Name: transaction fkey_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT fkey_customer_id FOREIGN KEY (customer_id) REFERENCES public.customer(id) NOT VALID;


--
-- Name: notification fkey_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT fkey_customer_id FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- Name: transaction fkey_source_account_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT fkey_source_account_id FOREIGN KEY (source_account_id) REFERENCES public.account(id) NOT VALID;


--
-- Name: transaction fkey_target_account_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT fkey_target_account_id FOREIGN KEY (target_account_id) REFERENCES public.account(id) NOT VALID;


--
-- PostgreSQL database dump complete
--

